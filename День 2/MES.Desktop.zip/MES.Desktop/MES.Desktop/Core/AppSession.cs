﻿using System;
using MES.Desktop.Models;
namespace MES.Desktop.Core
{
    public static class AppSession { public static User Current { get; set; } }
    public static class Messenger
    {
        public static event Action<string, object> OnMessage;
        public static void Send(string token, object payload = null)
        {
            var h = OnMessage; if (h != null) h(token, payload);
        }
    }
}