﻿using System.Collections.ObjectModel;
using System.Data.SqlClient;
using Dapper;
using System.Linq;
using MES.Desktop.Models;

namespace MES.Desktop.Data
{
    public class DataRepository
    {
        public ObservableCollection<ProductionOrder> GetOrders()
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                // Исправлено: snake_case столбцы с AS alias'ами
                var sql = @"
                    SELECT 
                        id AS Id, 
                        order_number AS OrderNumber, 
                        recipe_id AS RecipeId, 
                        planned_quantity_kg AS PlannedQuantityKg, 
                        status AS Status, 
                        planned_start_date AS PlannedStartDate 
                    FROM ProductionOrders 
                    WHERE status <> 'archived'";

                return new ObservableCollection<ProductionOrder>(c.Query<ProductionOrder>(sql));
            }
        }

        public ObservableCollection<ProductionStep> GetSteps(int batchId)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                // Исправлено: batch_id и step_order
                var sql = @"
                    SELECT 
                        id AS Id, batch_id AS BatchId, step_order AS StepOrder, 
                        step_name AS StepName, planned_temp_c AS PlannedTempC, 
                        actual_temp_c AS ActualTempC, planned_duration_min AS PlannedDurationMin, 
                        actual_duration_min AS ActualDurationMin, planned_pressure_bar AS PlannedPressureBar, 
                        actual_pressure_bar AS ActualPressureBar, deviation_flag AS DeviationFlag, 
                        operator_comment AS OperatorComment, recorded_by AS RecordedBy, 
                        created_at AS CreatedAt
                    FROM ProductionSteps 
                    WHERE batch_id = @Id ORDER BY step_order";

                return new ObservableCollection<ProductionStep>(c.Query<ProductionStep>(sql, new { Id = batchId }));
            }
        }

        public bool SaveStep(ProductionStep s)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                // Исправлено: имена столбцов в UPDATE должны быть snake_case
                var sql = @"
                    UPDATE ProductionSteps SET 
                        actual_temp_c = @ActualTempC, 
                        actual_duration_min = @ActualDurationMin, 
                        actual_pressure_bar = @ActualPressureBar, 
                        operator_comment = @OperatorComment 
                    WHERE id = @Id";

                return c.Execute(sql, s) > 0;
            }
        }

        public ObservableCollection<ProductionStep> GetDeviations()
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                // Исправлено: deviation_flag
                var sql = @"
                    SELECT 
                        id AS Id, batch_id AS BatchId, step_order AS StepOrder, 
                        step_name AS StepName, planned_temp_c AS PlannedTempC, 
                        actual_temp_c AS ActualTempC, planned_duration_min AS PlannedDurationMin, 
                        actual_duration_min AS ActualDurationMin, planned_pressure_bar AS PlannedPressureBar, 
                        actual_pressure_bar AS ActualPressureBar, deviation_flag AS DeviationFlag, 
                        operator_comment AS OperatorComment, recorded_by AS RecordedBy, 
                        created_at AS CreatedAt
                    FROM ProductionSteps 
                    WHERE deviation_flag = 1";

                return new ObservableCollection<ProductionStep>(c.Query<ProductionStep>(sql));
            }
        }

        public bool RegisterUser(User u, string pwd)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                // Проверка на существующего пользователя
                if (c.ExecuteScalar<int>("SELECT COUNT(*) FROM Users WHERE username = @U", new { U = u.Username }) > 0)
                    return false;

                u.PasswordHash = BCrypt.Net.BCrypt.HashPassword(pwd);

                // Исправлено: имена столбцов в INSERT
                var sql = @"
                    INSERT INTO Users 
                    (id, username, password_hash, full_name, role, email, phone, is_active, created_at, department) 
                    VALUES 
                    (0, @Username, @PasswordHash, @FullName, @Role, @Email, @Phone, 1, GETUTCDATE(), @Department)";

                return c.Execute(sql, u) > 0;
            }
        }
    }
}