﻿namespace MES.Desktop.Data
{
    public static class DbConfig
    {
        public static string ConnectionString = "Server=pc\\SQLEXPRESS;Database=MES_Production;Trusted_Connection=True;";
    }
}