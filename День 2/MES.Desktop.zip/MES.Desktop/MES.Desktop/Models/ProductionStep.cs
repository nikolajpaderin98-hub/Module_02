﻿using System;
namespace MES.Desktop.Models
{
    public class ProductionStep
    {
        public int Id { get; set; }
        public int BatchId { get; set; }
        public int StepOrder { get; set; }
        public string StepName { get; set; }
        public decimal? PlannedTempC { get; set; }
        public decimal? ActualTempC { get; set; }
        public int? PlannedDurationMin { get; set; }
        public int? ActualDurationMin { get; set; }
        public decimal? PlannedPressureBar { get; set; }
        public decimal? ActualPressureBar { get; set; }
        public bool DeviationFlag { get; set; }
        public string OperatorComment { get; set; }
        public int? RecordedBy { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}