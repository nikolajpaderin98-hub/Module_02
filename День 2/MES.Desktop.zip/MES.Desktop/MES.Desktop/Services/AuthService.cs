﻿using BCrypt.Net;
using Dapper;
using MES.Desktop.Data;
using MES.Desktop.Models;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MES.Desktop.Services
{
    public class AuthService
    {
        public async Task<User> LoginAsync(string login, string pwd)
        {
            try
            {
                Debug.WriteLine($"🔍 Вход: {login}");

                using (var c = new SqlConnection(DbConfig.ConnectionString))
                {
                    await c.OpenAsync();

                    var sql = @"
                        SELECT 
                            id, 
                            username, 
                            password_hash, 
                            is_active
                        FROM Users 
                        WHERE username = @Username";

                    var userDynamic = (await c.QueryAsync(sql, new { Username = login })).FirstOrDefault();

                    if (userDynamic == null)
                    {
                        Debug.WriteLine("❌ Пользователь не найден");
                        return null;
                    }

                    // ИСПРАВЛЕНО: is_active приходит как bool из SQL Server (bit)
                    bool isActiveValue = userDynamic.is_active;
                    Debug.WriteLine($"IsActive значение из БД: {isActiveValue}");

                    if (!isActiveValue)
                    {
                        Debug.WriteLine("❌ Пользователь не активен");
                        return null;
                    }

                    // Создаем объект User вручную
                    var user = new User
                    {
                        Id = userDynamic.id,
                        Username = userDynamic.username,
                        PasswordHash = userDynamic.password_hash,
                        IsActive = true // Явно устанавливаем true
                    };

                    // Проверяем пароль
                    bool isValid = BCrypt.Net.BCrypt.Verify(pwd, user.PasswordHash);
                    Debug.WriteLine($"Пароль верен: {isValid}");

                    return isValid ? user : null;
                }
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine($"❌ Ошибка: {ex.Message}");
                return null;
            }
        }
    }
}