﻿using System.Windows;
using System.Threading.Tasks;
using MES.Desktop.Core;
using MES.Desktop.Services;
using MES.Desktop.Data;
using MES.Desktop.Models;
using MES.Desktop.Views;

namespace MES.Desktop.ViewModels
{
    public class LoginViewModel : ObservableObject
    {
        private readonly AuthService _auth = new AuthService();
        private readonly DataRepository _repo = new DataRepository();
        private string _user = "", _pass = "", _status = "", _role = "operator";
        private bool _isReg = false;

        public string Username { get { return _user; } set { _user = value; OnPropertyChanged("Username"); } }
        public string Password { get { return _pass; } set { _pass = value; OnPropertyChanged("Password"); } }
        public string Status { get { return _status; } set { _status = value; OnPropertyChanged("Status"); } }
        public string RegRole { get { return _role; } set { _role = value; OnPropertyChanged("RegRole"); } }
        public bool IsRegisterMode { get { return _isReg; } set { _isReg = value; OnPropertyChanged("IsRegisterMode"); } }

        public RelayCommand LoginCmd { get; private set; }
        public RelayCommand RegCmd { get; private set; }
        public RelayCommand ToggleCmd { get; private set; }

        public LoginViewModel Init()
        {
            LoginCmd = new RelayCommand(async p => await DoLogin());
            RegCmd = new RelayCommand(async p => await DoReg());
            ToggleCmd = new RelayCommand(p => { IsRegisterMode = !IsRegisterMode; Status = ""; });
            return this;
        }

        private async Task DoLogin()
        {
            var u = await _auth.LoginAsync(Username, Password);
            if (u != null) { AppSession.Current = u; new MainWindow().Show(); Application.Current.Windows[0].Close(); }
            else Status = "❌ Ошибка входа";
        }

        private async Task DoReg()
        {
            var u = new User { Username = Username, FullName = Username, Role = RegRole, Email = "", Phone = "", Department = "Новый" };
            if (_repo.RegisterUser(u, Password)) { Status = "✅ Успешно. Войдите."; IsRegisterMode = false; }
            else Status = "❌ Логин занят";
        }
    }
}