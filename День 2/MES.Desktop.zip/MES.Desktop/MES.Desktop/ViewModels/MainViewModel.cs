﻿using System.Collections;
using System.Windows;
using MES.Desktop.Core;
using MES.Desktop.Data;
using MES.Desktop.Models;

namespace MES.Desktop.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        private readonly DataRepository _repo = new DataRepository();
        private string _viewTitle = "📊 Конвейер заказов";
        private object _currentContent;

        public string ViewTitle
        {
            get { return _viewTitle; }
            set { _viewTitle = value; OnPropertyChanged("ViewTitle"); }
        }

        public object CurrentContent
        {
            get { return _currentContent; }
            set { _currentContent = value; OnPropertyChanged("CurrentContent"); }
        }

        public RelayCommand GoOrdersCmd { get; private set; }
        public RelayCommand GoStepsCmd { get; private set; }
        public RelayCommand GoDevCmd { get; private set; }
        public RelayCommand LogoutCmd { get; private set; }

        public MainViewModel()
        {
            GoOrdersCmd = new RelayCommand(p => { ViewTitle = "📊 Заказы"; CurrentContent = _repo.GetOrders(); });
            GoStepsCmd = new RelayCommand(p => { ViewTitle = "🏭 Цех (Batch 1)"; CurrentContent = new Views.StepInputView(1); });
            GoDevCmd = new RelayCommand(p => { ViewTitle = "⚠️ Отклонения"; CurrentContent = _repo.GetDeviations(); });
            LogoutCmd = new RelayCommand(p => { AppSession.Current = null; new Views.LoginWindow().Show(); Application.Current.Windows[0].Close(); });
        }
    }
}