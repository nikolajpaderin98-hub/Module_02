﻿using System.Collections.ObjectModel;
using MES.Desktop.Core;
using MES.Desktop.Data;
using MES.Desktop.Models;
namespace MES.Desktop.ViewModels
{
    public class StepInputViewModel : ObservableObject
    {
        private readonly DataRepository _repo = new DataRepository();
        private ProductionStep _sel;
        private string _comm = "", _msg = "";
        private int _batchId;
        public ObservableCollection<ProductionStep> Steps { get; private set; } = new ObservableCollection<ProductionStep>();
        public ProductionStep SelectedStep { get { return _sel; } set { _sel = value; OnPropertyChanged("SelectedStep"); } }
        public string Comment { get { return _comm; } set { _comm = value; OnPropertyChanged("Comment"); } }
        public string Message { get { return _msg; } set { _msg = value; OnPropertyChanged("Message"); } }
        public RelayCommand SaveCmd { get; private set; }
        public StepInputViewModel(int batchId)
        {
            _batchId = batchId; Refresh();
            SaveCmd = new RelayCommand(Save);
        }
        private void Refresh() { Steps.Clear(); foreach (var s in _repo.GetSteps(_batchId)) Steps.Add(s); Message = ""; }
        private void Save(object p)
        {
            if (SelectedStep == null) { Message = "⚠️ Выберите шаг"; return; }
            SelectedStep.OperatorComment = Comment;
            if (_repo.SaveStep(SelectedStep)) { Message = "✅ Сохранено. Триггеры БД обновили статус."; Refresh(); }
            else Message = "❌ Ошибка";
        }
    }
}