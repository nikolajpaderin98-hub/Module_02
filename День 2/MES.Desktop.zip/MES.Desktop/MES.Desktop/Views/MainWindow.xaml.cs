﻿using System.Windows;
using MES.Desktop.ViewModels;

namespace MES.Desktop.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent(); // Теперь найдётся, если Build Action = Page
            DataContext = new MainViewModel();
        }
    }
}