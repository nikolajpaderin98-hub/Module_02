﻿using System.Windows.Controls;
namespace MES.Desktop.Views
{
    public partial class StepInputView : UserControl
    {
        public StepInputView(int batchId) { InitializeComponent(); DataContext = new ViewModels.StepInputViewModel(batchId); }
    }
}