﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace MES.OperatorModule.Converters
{
    public class BoolToStatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool boolValue)
            {
                return boolValue ? "✅ Выполнено" : "⏳ Ожидает";
            }
            return "⏳ Ожидает";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}