﻿using MES.OperatorModule.Models;

namespace MES.OperatorModule.Core
{
    public static class AppSession
    {
        public static User CurrentUser { get; set; }
    }
}