﻿using System.Collections.ObjectModel;
using System.Data.SqlClient;
using Dapper;
using MES.OperatorModule.Models;

namespace MES.OperatorModule.Data
{
    public class DataRepository
    {
        public ObservableCollection<OperatorBatch> GetActiveBatches()
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"SELECT Id, BatchNumber, ProductionLine, RecipeName, Status, 
                                   CurrentStepId, StartedAt, CompletedAt, OperatorId
                           FROM OperatorBatches WHERE Status = 'Active' ORDER BY StartedAt DESC";
                var list = c.Query<OperatorBatch>(sql);
                var result = new ObservableCollection<OperatorBatch>();
                foreach (var b in list) result.Add(b);
                return result;
            }
        }

        public ObservableCollection<ProductionStep> GetStepsForBatch(int batchId)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"SELECT Id, BatchId, StepOrder, StepName, Instruction,
                                   PlannedTempC, PlannedPressureBar, PlannedDurationMin,
                                   MinTempC, MaxTempC, MinPressureBar, MaxPressureBar,
                                   IsCompleted, StartedAt, CompletedAt,
                                   ActualTempC, ActualPressureBar, OperatorNote
                           FROM ProductionSteps WHERE BatchId = @Id ORDER BY StepOrder";
                var list = c.Query<ProductionStep>(sql, new { Id = batchId });
                var result = new ObservableCollection<ProductionStep>();
                foreach (var s in list) result.Add(s);
                return result;
            }
        }

        public ObservableCollection<TelemetryData> GetTelemetryForBatch(int batchId)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"SELECT t.Id, t.EquipmentId, e.EquipmentName, t.BatchId,
                                   t.TemperatureC, t.PressureBar, t.RotationRPM,
                                   t.PowerConsumptionKW, t.VibrationLevel,
                                   t.RecordedAt, t.IsAlert
                           FROM EquipmentTelemetry t
                           LEFT JOIN Equipment e ON t.EquipmentId = e.EquipmentCode
                           WHERE t.BatchId = @Id
                           ORDER BY t.RecordedAt DESC";
                var list = c.Query<TelemetryData>(sql, new { Id = batchId });
                var result = new ObservableCollection<TelemetryData>();
                foreach (var t in list) result.Add(t);
                return result;
            }
        }

        public ProductionStep GetStepById(int stepId)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"SELECT * FROM ProductionSteps WHERE Id = @Id";
                return c.QueryFirstOrDefault<ProductionStep>(sql, new { Id = stepId });
            }
        }

        public bool UpdateStepData(ProductionStep step)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"UPDATE ProductionSteps SET 
                                   ActualTempC = @ActualTempC,
                                   ActualPressureBar = @ActualPressureBar,
                                   OperatorNote = @OperatorNote,
                                   IsCompleted = @IsCompleted,
                                   CompletedAt = CASE WHEN @IsCompleted = 1 THEN GETDATE() ELSE CompletedAt END
                           WHERE Id = @Id";
                return c.Execute(sql, step) > 0;
            }
        }

        public bool LogOperatorAction(int batchId, int? stepId, string operatorName,
                                     string actionType, string actionData)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"INSERT INTO OperatorActions 
                           (BatchId, StepId, OperatorName, ActionType, ActionData) 
                           VALUES (@BatchId, @StepId, @OperatorName, @ActionType, @ActionData)";
                return c.Execute(sql, new
                {
                    BatchId = batchId,
                    StepId = stepId,
                    OperatorName = operatorName,
                    ActionType = actionType,
                    ActionData = actionData
                }) > 0;
            }
        }

        public bool UpdateBatchCurrentStep(int batchId, int? stepId)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"UPDATE OperatorBatches SET CurrentStepId = @StepId WHERE Id = @BatchId";
                return c.Execute(sql, new { BatchId = batchId, StepId = stepId }) > 0;
            }
        }

        public bool CompleteBatch(int batchId)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                var sql = @"UPDATE OperatorBatches SET Status = 'Completed', CompletedAt = GETDATE() 
                           WHERE Id = @Id";
                return c.Execute(sql, new { Id = batchId }) > 0;
            }
        }
    }
}