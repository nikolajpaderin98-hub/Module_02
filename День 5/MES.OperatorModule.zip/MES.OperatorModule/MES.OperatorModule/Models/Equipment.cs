﻿namespace MES.OperatorModule.Models
{
    public class Equipment
    {
        public int Id { get; set; }
        public string EquipmentCode { get; set; }
        public string EquipmentName { get; set; }
        public string ProductionLine { get; set; }
        public bool IsActive { get; set; }
    }
}