﻿using System;

namespace MES.OperatorModule.Models
{
    public class OperatorAction
    {
        public int Id { get; set; }
        public int BatchId { get; set; }
        public int? StepId { get; set; }
        public string OperatorName { get; set; }
        public string ActionType { get; set; }
        public string ActionData { get; set; }
        public DateTime RecordedAt { get; set; }
    }
}