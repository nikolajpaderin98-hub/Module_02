﻿using System;

namespace MES.OperatorModule.Models
{
    public class OperatorBatch
    {
        public int Id { get; set; }
        public string BatchNumber { get; set; }
        public string ProductionLine { get; set; }
        public string RecipeName { get; set; }
        public string Status { get; set; }
        public int? CurrentStepId { get; set; }
        public DateTime StartedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public int? OperatorId { get; set; }
    }
}