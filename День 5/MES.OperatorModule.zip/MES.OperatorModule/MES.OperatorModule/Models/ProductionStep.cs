﻿using System;

namespace MES.OperatorModule.Models
{
    public class ProductionStep
    {
        public int Id { get; set; }
        public int BatchId { get; set; }
        public int StepOrder { get; set; }
        public string StepName { get; set; }
        public string Instruction { get; set; }

        // Плановые параметры
        public decimal? PlannedTempC { get; set; }
        public decimal? PlannedPressureBar { get; set; }
        public int? PlannedDurationMin { get; set; }

        // Допустимые диапазоны
        public decimal? MinTempC { get; set; }
        public decimal? MaxTempC { get; set; }
        public decimal? MinPressureBar { get; set; }
        public decimal? MaxPressureBar { get; set; }

        // Статус выполнения
        public bool IsCompleted { get; set; }
        public DateTime? StartedAt { get; set; }
        public DateTime? CompletedAt { get; set; }

        // Ввод оператора
        public decimal? ActualTempC { get; set; }
        public decimal? ActualPressureBar { get; set; }
        public string OperatorNote { get; set; }
    }
}