﻿using System;

namespace MES.OperatorModule.Models
{
    public class TelemetryData
    {
        public int Id { get; set; }
        public string EquipmentId { get; set; }
        public string EquipmentName { get; set; }
        public int BatchId { get; set; }

        public decimal? TemperatureC { get; set; }
        public decimal? PressureBar { get; set; }
        public int? RotationRPM { get; set; }
        public decimal? PowerConsumptionKW { get; set; }
        public decimal? VibrationLevel { get; set; }

        public DateTime RecordedAt { get; set; }
        public bool IsAlert { get; set; }

        // Для отображения статуса
        public string Status => IsAlert ? "⚠️ Авария" : "✅ Норма";
        public string StatusColor => IsAlert ? "#D32F2F" : "#4CAF50";
    }
}