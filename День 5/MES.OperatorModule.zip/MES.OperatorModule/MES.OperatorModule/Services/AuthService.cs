﻿using BCrypt.Net;  // ✅ Правильный namespace
using Dapper;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MES.OperatorModule.Data;
using MES.OperatorModule.Models;  // ✅ Добавлено

namespace MES.OperatorModule.Services
{
    public class AuthService
    {
        public async Task<User> LoginAsync(string username, string password)
        {
            using (var c = new SqlConnection(DbConfig.ConnectionString))
            {
                await c.OpenAsync();

                System.Diagnostics.Debug.WriteLine($"🔍 Попытка входа: {username}");

                var sql = @"SELECT id AS Id, username AS Username, password_hash AS PasswordHash, 
                   full_name AS FullName, role AS Role, is_active AS IsActive,
                   email AS Email, department AS Department
                   FROM Users WHERE username = @Username";

                var user = (await c.QueryAsync<User>(sql, new { Username = username })).FirstOrDefault();

                if (user == null)
                {
                    System.Diagnostics.Debug.WriteLine("❌ Пользователь не найден в БД");
                    return null;
                }

                System.Diagnostics.Debug.WriteLine($"✅ Пользователь найден: {user.FullName}");
                System.Diagnostics.Debug.WriteLine($"📋 Роль: {user.Role}, Активен: {user.IsActive}");

                if (!user.IsActive)
                {
                    System.Diagnostics.Debug.WriteLine("❌ Пользователь не активен");
                    return null;
                }

                if (user.Role != "operator" && user.Role != "admin")
                {
                    System.Diagnostics.Debug.WriteLine($"❌ Недопустимая роль: {user.Role}");
                    return null;
                }

                bool isValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
                System.Diagnostics.Debug.WriteLine($"🔑 Проверка пароля: {isValid}");

                return isValid ? user : null;
            }
        }
    
    }
}