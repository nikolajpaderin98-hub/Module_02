﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Timers;
using MES.OperatorModule.Data;
using MES.OperatorModule.Models;

namespace MES.OperatorModule.Services
{
    public class TelemetryService : IDisposable
    {
        private readonly DataRepository _repo = new DataRepository();
        private Timer _updateTimer;
        private int _currentBatchId;
        public event Action<ObservableCollection<TelemetryData>> TelemetryUpdated;

        public void StartMonitoring(int batchId)
        {
            _currentBatchId = batchId;
            _updateTimer = new Timer(2000); // Обновление каждые 2 секунды
            _updateTimer.Elapsed += async (s, e) => await FetchTelemetry();
            _updateTimer.Start();
        }

        private async Task FetchTelemetry()
        {
            var telemetry = _repo.GetTelemetryForBatch(_currentBatchId);
            // Симуляция обновления данных
            foreach (var t in telemetry)
            {
                if (t.TemperatureC.HasValue)
                    t.TemperatureC += (decimal)(new Random().NextDouble() * 0.5 - 0.25);
            }
            TelemetryUpdated?.Invoke(telemetry);
        }

        public void StopMonitoring()
        {
            _updateTimer?.Stop();
            _updateTimer?.Dispose();
        }

        public void Dispose() => StopMonitoring();
    }
}