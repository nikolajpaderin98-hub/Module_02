﻿using System.Windows;
using MES.OperatorModule.Core;
using MES.OperatorModule.Data;
using MES.OperatorModule.Models;
using MES.OperatorModule.Views;  // ✅ Добавлено
using System.Collections.ObjectModel;

namespace MES.OperatorModule.ViewModels
{
    public class ActiveBatchesViewModel : ObservableObject
    {
        private readonly DataRepository _repo = new DataRepository();
        private OperatorBatch _selectedBatch;

        public ObservableCollection<OperatorBatch> Batches { get; }
        public OperatorBatch SelectedBatch
        {
            get => _selectedBatch;
            set { _selectedBatch = value; OnPropertyChanged(); OnPropertyChanged("CanOpenBatch"); }
        }
        public bool CanOpenBatch => SelectedBatch != null;

        public RelayCommand LoadCmd { get; }
        public RelayCommand OpenBatchCmd { get; }
        public RelayCommand LogoutCmd { get; }

        public ActiveBatchesViewModel()
        {
            Batches = _repo.GetActiveBatches();
            LoadCmd = new RelayCommand(p => LoadBatches());
            OpenBatchCmd = new RelayCommand(p => OpenBatch(), p => CanOpenBatch);
            LogoutCmd = new RelayCommand(p => Logout());
        }

        private void LoadBatches()
        {
            var list = _repo.GetActiveBatches();
            Batches.Clear();
            foreach (var b in list) Batches.Add(b);
        }

        private void OpenBatch()
        {
            if (SelectedBatch != null)
            {
                var window = new BatchProgramWindow(SelectedBatch);  // ✅ Теперь найдётся
                window.Show();
            }
        }

        private void Logout()
        {
            AppSession.CurrentUser = null;
            new LoginWindow().Show();  // ✅ Теперь найдётся
            Application.Current.Windows[0].Close();
        }
    }
}