﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using MES.OperatorModule.Core;
using MES.OperatorModule.Data;
using MES.OperatorModule.Models;
using MES.OperatorModule.Services;
using MES.OperatorModule.Views;  // ✅ Добавлено
using Microsoft.VisualBasic;  // ✅ Для Interaction

namespace MES.OperatorModule.ViewModels
{
    public class BatchProgramViewModel : ObservableObject, IDisposable
    {
        private readonly DataRepository _repo = new DataRepository();
        private readonly TelemetryService _telemetry = new TelemetryService();
        private ProductionStep _selectedStep;
        private OperatorBatch _batch;

        public ObservableCollection<ProductionStep> Steps { get; }
        public ObservableCollection<TelemetryData> Telemetry { get; }

        public ProductionStep SelectedStep
        {
            get => _selectedStep;
            set { _selectedStep = value; OnPropertyChanged(); OnPropertyChanged("CanStartStep"); OnPropertyChanged("CanCompleteStep"); }
        }

        public OperatorBatch Batch => _batch;
        public string CurrentOperator => AppSession.CurrentUser?.FullName;

        public bool CanStartStep => SelectedStep != null && !SelectedStep.IsCompleted && SelectedStep.StartedAt == null;
        public bool CanCompleteStep => SelectedStep != null && !SelectedStep.IsCompleted && SelectedStep.StartedAt != null;

        public RelayCommand StartStepCmd { get; }
        public RelayCommand CompleteStepCmd { get; }
        public RelayCommand SaveDataCmd { get; }
        public RelayCommand ReportIssueCmd { get; }
        public RelayCommand BackCmd { get; }

        public BatchProgramViewModel(OperatorBatch batch)
        {
            _batch = batch;
            Steps = _repo.GetStepsForBatch(batch.Id);
            Telemetry = new ObservableCollection<TelemetryData>();

            _telemetry.TelemetryUpdated += data => { Telemetry.Clear(); foreach (var t in data) Telemetry.Add(t); };
            _telemetry.StartMonitoring(batch.Id);

            StartStepCmd = new RelayCommand(p => StartStep(), p => CanStartStep);
            CompleteStepCmd = new RelayCommand(p => CompleteStep(), p => CanCompleteStep);
            SaveDataCmd = new RelayCommand(p => SaveStepData());
            ReportIssueCmd = new RelayCommand(p => ReportIssue());
            BackCmd = new RelayCommand(p => GoBack());
        }

        private void StartStep()
        {
            if (SelectedStep == null) return;
            SelectedStep.StartedAt = DateTime.Now;
            _repo.UpdateStepData(SelectedStep);
            _repo.LogOperatorAction(_batch.Id, SelectedStep.Id, CurrentOperator, "StartStep", SelectedStep.StepName);
            _repo.UpdateBatchCurrentStep(_batch.Id, SelectedStep.Id);
            OnPropertyChanged("CanStartStep");
            OnPropertyChanged("CanCompleteStep");
        }

        private void CompleteStep()
        {
            if (SelectedStep == null) return;
            SelectedStep.IsCompleted = true;
            SelectedStep.CompletedAt = DateTime.Now;
            _repo.UpdateStepData(SelectedStep);
            _repo.LogOperatorAction(_batch.Id, SelectedStep.Id, CurrentOperator, "CompleteStep", SelectedStep.StepName);

            if (Steps.All(s => s.IsCompleted))
            {
                _repo.CompleteBatch(_batch.Id);
                MessageBox.Show("✅ Партия завершена!", "Успех");
                GoBack();
            }
            else
            {
                OnPropertyChanged("CanStartStep");
                OnPropertyChanged("CanCompleteStep");
            }
        }

        private void SaveStepData()
        {
            if (SelectedStep == null) return;
            _repo.UpdateStepData(SelectedStep);
            _repo.LogOperatorAction(_batch.Id, SelectedStep.Id, CurrentOperator, "InputData",
                $"Temp: {SelectedStep.ActualTempC}, Pressure: {SelectedStep.ActualPressureBar}");
            MessageBox.Show("💾 Данные сохранены");
        }

        private void ReportIssue()
        {
            // Создаём простое окно для ввода текста
            var textBox = new System.Windows.Controls.TextBox();
            textBox.Width = 300;
            textBox.Height = 100;
            textBox.AcceptsReturn = true;
            textBox.TextWrapping = System.Windows.TextWrapping.Wrap;

            var window = new Window
            {
                Title = "Сообщить об отклонении",
                Width = 350,
                Height = 200,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Content = textBox
            };

            var button = new System.Windows.Controls.Button
            {
                Content = "OK",
                Width = 80,
                Height = 30,
                Margin = new System.Windows.Thickness(5)
            };

            var stackPanel = new System.Windows.Controls.StackPanel();
            stackPanel.Children.Add(new System.Windows.Controls.TextBlock
            {
                Text = "Опишите проблему:",
                Margin = new System.Windows.Thickness(5)
            });
            stackPanel.Children.Add(textBox);
            stackPanel.Children.Add(button);

            window.Content = stackPanel;

            bool? result = null;
            button.Click += (s, e) => { result = true; window.Close(); };

            if (window.ShowDialog() == true && !string.IsNullOrWhiteSpace(textBox.Text))
            {
                _repo.LogOperatorAction(_batch.Id, SelectedStep?.Id, CurrentOperator, "ReportIssue", textBox.Text);
                MessageBox.Show("⚠️ Отклонение зафиксировано");
            }
        }

        private void GoBack()
        {
            _telemetry.Dispose();
            foreach (Window w in Application.Current.Windows)  // ✅ Правильное приведение типа
            {
                if (w is ActiveBatchesWindow)  // ✅ Теперь найдётся
                {
                    w.Show();
                    break;
                }
            }
            Application.Current.Windows[0].Close();
        }

        public void Dispose() => _telemetry.Dispose();
    }
}