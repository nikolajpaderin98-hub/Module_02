﻿using System.Threading.Tasks;
using System.Windows;
using MES.OperatorModule.Core;
using MES.OperatorModule.Services;
using MES.OperatorModule.Views;

namespace MES.OperatorModule.ViewModels
{
    public class LoginViewModel : ObservableObject
    {
        private readonly AuthService _auth = new AuthService();
        private string _username, _password, _status;

        public string Username { get => _username; set { _username = value; OnPropertyChanged(); } }
        public string Password { get => _password; set { _password = value; OnPropertyChanged(); } }
        public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }

        public RelayCommand LoginCmd { get; }

        public LoginViewModel()
        {
            LoginCmd = new RelayCommand(async p => await DoLogin());
        }

        private async Task DoLogin()
        {
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            {
                Status = "❌ Введите логин и пароль";
                return;
            }

            var user = await _auth.LoginAsync(Username, Password);
            if (user != null)
            {
                AppSession.CurrentUser = user;
                new ActiveBatchesWindow().Show();
                Application.Current.Windows[0].Close();
            }
            else
            {
                Status = "❌ Неверный логин или пароль";
            }
        }
    }
}