﻿using System.Windows;
using MES.OperatorModule.ViewModels;

namespace MES.OperatorModule.Views
{
    public partial class ActiveBatchesWindow : Window
    {
        public ActiveBatchesWindow() { InitializeComponent(); DataContext = new ActiveBatchesViewModel(); }
    }
}