﻿using System;
using System.Windows;
using MES.OperatorModule.Models;
using MES.OperatorModule.ViewModels;

namespace MES.OperatorModule.Views
{
    public partial class BatchProgramWindow : Window
    {
        private BatchProgramViewModel _vm;

        public BatchProgramWindow(OperatorBatch batch)
        {
            InitializeComponent();
            _vm = new BatchProgramViewModel(batch);
            DataContext = _vm;
        }

        protected override void OnClosed(EventArgs e)
        {
            _vm?.Dispose();
            base.OnClosed(e);
        }
    }
}