﻿using System.Windows;
using System.Windows.Controls;
using MES.OperatorModule.ViewModels;

namespace MES.OperatorModule.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow() { InitializeComponent(); DataContext = new LoginViewModel(); }
        private void PwdBox_PasswordChanged(object s, RoutedEventArgs e) { if (DataContext is LoginViewModel vm) vm.Password = ((PasswordBox)s).Password; }
    }
}